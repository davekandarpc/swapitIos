import React, { useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View, ScrollView, TextInput,FlatList, SafeAreaView } from 'react-native';
import { styles } from './styles.js';
import FontAwesome from 'react-native-vector-icons/dist/FontAwesome';
import AntDesign from 'react-native-vector-icons/dist/AntDesign';
import { TextBox } from '../index'

FontAwesome.loadFont()
AntDesign.loadFont()

export const SearchableDropDown = ({
  placeholder,
  menuData,
  value,
  onSelectItem,
  propsChangeText,
  errors,
  DropdownPropStyle,
  noLabel = false,
  editable = true,
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const [textBoxValue, setTextBoxValue] = useState('');
  const [searchData, setSearchData] = useState(menuData)
  const [selectTextItem, setSelectTextItem] =  useState('')

  const onSelectTextItem = (item) => {
      setShowMenu(true)
      setTextBoxValue(item);
  }

  const onChangeText = (value) => {
    setShowMenu(true)
    setTextBoxValue(value);
    if(propsChangeText) {
      propsChangeText(value);
    }
    onSearch(value)
  }

  const onSearch = (searchTerm) => {
    var searchReslut = menuData.filter(function (item) {
      return item.label.includes(searchTerm);
    });
    setSearchData(searchReslut)
    console.log('searchReslut: ' + JSON.stringify(searchReslut))
  }

  return (
    <View style={DropdownPropStyle}>
      <TouchableOpacity>
        <TextBox 
            noLabel={noLabel}
            label={placeholder}
            value={value !== '' ? value : textBoxValue}
            propsChangeText={onSelectTextItem}
            //onChangeText={onChangeText}
            onFocusInput={() => setShowMenu(true)}
            onBlurInput={() => setShowMenu(false)}
            errors={!showMenu ? errors : []}
            editable={editable}
        />
      </TouchableOpacity>
      {
        showMenu ?
          <View style={styles.menuContainer}>
            <ScrollView nestedScrollEnabled={true} keyboardShouldPersistTaps="always">
              {
                menuData.length > 0 ? menuData.map((item) => {
                  return (
                    <TouchableOpacity
                      style={styles.menuItem}
                      onPress={() => {
                        setShowMenu(false)
                        onSelectItem(item)
                      }}
                    >
                      <Text style={styles.menuTitle}>{item.label}</Text>
                    </TouchableOpacity>
                  )
                })
                  :
                  <View
                    style={styles.menuItem}
                  >
                    <Text style={styles.menuTitle}>No Data Found</Text>
                  </View>
              }
            </ScrollView>
          </View>
          :
          null
      }
    </View >
  );
};
