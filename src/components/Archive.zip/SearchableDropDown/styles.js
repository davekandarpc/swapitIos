import { StyleSheet } from 'react-native';
export const styles = StyleSheet.create({
  //searchble drop down component start
  menuContainer: {
    borderWidth: 1,
    maxHeight: 150,
    overflow: 'hidden',
    marginTop: -13,
    backgroundColor: 'lightgrey',
    borderColor: 'lightgrey'
  },
  menuItem: {
    borderBottomWidth: 0.5,
    paddingHorizontal: 12,
    paddingVertical: 8
  },
   menuTitle: {
    fontSize: 16,
    color: '#000'
  },
});