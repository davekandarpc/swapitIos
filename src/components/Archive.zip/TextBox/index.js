import React, { useState } from 'react';
import { styles } from './styles.js'
import { TextInput, View, Text, TouchableOpacity } from 'react-native'

export const TextBox = ({ noLabel = false, onChangeText, label, style, errors, onFocusInput, onBlurInput, children, editable = true, ...props }) => {
    const [isFocued, setIsFocused] = useState(false)
    return (
        <View style={[styles.textBoxContainerStyle, style]}>
           
            <TouchableOpacity>
                <TextInput
                    {...props}
                    placeholder={label}
                    placeholderTextColor='#777'
                    style={styles.textBoxStyle}
                    onFocus={() => {
                        setIsFocused(true)
                        if (onFocusInput) {
                            onFocusInput()
                        }
                    }}
                    onBlur={() => {
                        setIsFocused(false)
                        if (onBlurInput) {
                            onBlurInput()
                        }
                    }}
                    editable={editable}
                />
            {
                errors?.map(message => <Text key={message} style={styles.error}>{message}</Text>)
            }
            {children}
            </TouchableOpacity>
        </View>
    );
};
