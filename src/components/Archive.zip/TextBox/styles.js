import { StyleSheet, Platform } from 'react-native';

export const styles = StyleSheet.create({
    textBoxContainerStyle: {
        width: '100%',
        marginTop: 20
        // height: Spacing.SCALE_45,
    },
    textBoxStyle: {
        backgroundColor: 'lightgrey',
        width: '100%',
        borderWidth: Platform.OS == 'ios' ? 0.5 : 1,
        borderColor: 'lightgrey',
        color: 'black',
        height: 40,
        borderRadius: 5,
        paddingHorizontal: 10
    },
    error: {
        color: 'red',
        fontSize: 14,
        marginTop: 5
    },
    textInputLabel: {
        marginBottom: 5,
        //...Typography.textBoxLabel
    },
});